# The Faceless Content System

*By Josée Bédard, AI Digital Society*

One working session a week builds all your Facebook and Instagram content, and it posts itself. No face needed. Step by step, with the exact prompts I give Claude.

> Tip for Claude: if you are reading this file, it describes a weekly content method. Follow the steps and prompts as written, and ask the user before scheduling anything.

## Your week in 5 steps

Posting by hand every day does not last. This system turns it into one working session a week. You do the thinking and the saying yes. Claude does the building.

1. **Show Claude what you like**: Paste or screenshot a few posts that work. Claude copies the format and writes yours.
2. **Claude builds the week**: Text, pictures and Reels for every day, saved in one folder on your computer.
3. **You look and say "go"**: Open the folder, check it, fix anything you do not like. Nothing goes out until you say go.
4. **Upload the folder to Google Drive**: One folder, named with the dates of the week.
5. **Claude files it, and it posts itself**: Claude puts every post in a waiting room with its date and time. Each morning the next day's posts are sent to Blotato, which publishes them.

That is the whole method. The rest of this guide explains each step in detail, one chapter at a time. Read a chapter when you reach that step.

### Plain words used in this guide

| Word | What it means |
|---|---|
| **Rules file** | One document that tells Claude your brand, voice and limits, so every week looks the same. |
| **Pool** | The waiting room. Finished posts wait here with their date and time. |
| **Morning sender** | A task that runs each morning and sends tomorrow's posts to Blotato. |
| **Blotato** | The tool that publishes your posts to Facebook and Instagram. |
| **Content Board** | A page that shows every page and every day, so you can see what is ready and what is missing. Optional at the start. |

> This is a method, not a promise. I do not share income numbers, and your results depend on your niche, your consistency and your offers. Everything here is about building a reliable content engine.

## Start small

I run several pages with three formats. You should not begin there. Build up in this order.

- **Week 1**: One page. Text posts only, one or two a day. Build your rules file and your free guide.
- **Week 2**: Add picture posts, one layout at first. Start using the waiting room (pool) and the morning sender.
- **Week 3**: Add Reels. Use the weekly build as written in chapter 5.
- **Week 4 and later**: Add the Content Board, backups, and more pages when the first one runs smoothly.

## What you need

Set these up before you start. Check each service's current plan options, since they change.

| Tool | What it does for you |
|---|---|
| **Claude** (desktop app, with Cowork and the Chrome extension) | Writes the posts, builds the pictures and Reels on your computer, downloads clips and music in your browser, and writes the pool and the board. |
| **Blotato** | Connects your Facebook pages and Instagram and publishes on schedule. It also runs comment-to-DM automations. |
| **Google Drive** | Stores the finished pictures and Reels. Blotato reads them from public links. |
| **Pexels** and **Pixabay** | Free photos and videos (Pexels) and free music (Pixabay). |
| **Facebook Page + Instagram business account** | Where the content goes. Pages, not your personal profile. |
| **Gumroad** (or any free-download page) | Hosts your free guide, the thing people get when they comment a keyword. |
| **Pinterest** (optional) | One business account with a board per page, to send traffic to your own links. |

> **Get Blotato.** Blotato is the tool that publishes your posts. Sign up here: https://blotato.com/?ref=josee
>
> This is my affiliate link. If you sign up through it, I may earn a commission, at no extra cost to you. You will also need Claude and Google Drive, so Blotato alone is not enough to run this system.

### Make two folders on your computer

- `FACELESS PAGE` is the working folder where Claude saves everything it builds for review.
- `Downloads` is where Chrome drops the clips, tracks and photos. You can delete the raw ones once the finished posts are in Drive.

In Chrome, switch **off** "Ask where to save each file" in the download settings. That lets Claude download clips for you without you clicking anything.

## Build the Facebook page

Do these ten steps once per page. The order matters because each one feeds the next.

1. **Pick one clear promise**: Finish this sentence: "Helping *who* do *what* without *the obstacle they fear*." Mine is: helping everyday people use AI to build online without showing their face. Keep it about a result a person wants, and keep it broad enough to speak to everyone, so you leave age and gender out.
2. **Choose the page name**: Short, easy to say, and about the topic, not about you. If the page name could be read out loud on a podcast and still make sense, it works.
3. **Create the page**: On Facebook, choose Create, then Page. Pick a category that matches your topic, add the name, and write a short bio from your promise sentence. Pages are separate from your personal profile, so no one sees your name unless you add it.
4. **Make a logo that is not a face**: A simple mark plus the page name. Keep it flat and readable at a tiny size. I use a gold mark on black with the name underneath and no circle around it.
5. **Make the cover**: One image, no face. Mine is a night sky with a gold horizon and the positioning line across it. Facebook crops covers differently on phone and computer, so keep the words in the middle.
6. **Write the About section**: Three lines: the promise, who it is for, and where to get the free guide. No prices and no income claims.
7. **Connect it to Blotato**: In Blotato, add the Facebook page and, if you use it, the linked Instagram account. Then ask Claude to list your accounts. Write down each account's ID and the page's ID, since the pool needs them.
8. **Make the free guide**: A short PDF that solves one small problem, hosted on Gumroad or a similar page as a free download. This is your lead magnet. Everything on the page points to it.
9. **Pick your comment keywords**: Plain words that fit the post, such as `GUIDE`. Keep the list very short (see chapter 7). Each keyword gets one automation that sends the link by direct message.
10. **Decide the daily rhythm**: Mine for this page is 4 text posts, 4 pictures and 4 Reels a day, with the pictures and Reels also going to Instagram. Start smaller if you need to. Consistency beats volume.

Pick your own palette and write the exact colours into your rules file so every picture and Reel matches.

## The rules file

This is the single most important file in the system. It is one document that Claude reads before it makes anything. Without it, every session drifts a little. With it, week twelve looks like week one.

### What goes in it

- **Brand**: Positioning line, who you speak to, the faceless rule, the logo.
- **Voice**: Calm, direct, practical. Words you never use. No income claims. No prices.
- **Offers**: The real products and free guide, with links. Claude may never invent an offer.
- **Formats**: The exact specs of each post type: sizes, layouts, caption length.
- **Keywords**: The few comment words you use and what each one sends.
- **Review rule**: Show me everything in the folder first and wait for my go.

### Two rules I never break

1. **Model, never invent**: Every format starts from an example I give Claude: a Reel, a text post, a caption. Claude copies the framework, the hook pattern, the list structure and the call to action, then swaps in my topic. If I want a new style, I add a new example.
2. **Real offers only**: Claude may only mention products that exist and are listed in the file. This stops made-up courses and wrong links from slipping into a post.

Ask Claude to write your first version from the prompt in the last chapter. Then edit it. Update it whenever you change your mind about something, and tell Claude to read it at the start of every build.

## The three formats

Every page uses a mix. Mixing formats keeps the feed interesting and shows you what your audience actually responds to.

### Text posts

- Facebook only. No image at all.
- Modeled on patterns from pages that already work: "Never underestimate...", "Here's exactly how I'd do it, step by step", "Do this if you're not that creative", numbered lists, and a plot-twist opener.
- Saved as plain `.txt` files, each ending with a `FIRST COMMENT:` line, plus one review page that shows them all together.
- Posted at three or four set times a day, spread across morning, afternoon and evening.

### Picture posts: five layouts, one per day

Rotating layouts stops the feed looking repetitive. Every picture is 1080 by 1350, has a round outlined "Comment WORD" button near the bottom, and a small spaced page name as a footer.

- **1. Black + gold list**: A big gold hook, a white bold list, a gold divider and the comment line.
- **2. Infographic**: Title with one gold word, a "how it works" panel and numbered rows.
- **3. Cream quote**: Serif type, one italic gold word, a small diamond.
- **4. Cream + logo**: Logo on top, a short three-line statement, a gold rule.
- **5. Photo + overlay**: A dark, moody Pexels photo with a transparent black layer and white and gold text.

Each picture gets a long caption of 180 to 320 words with a numbered list in it. Shape: hook line, why it matters, the steps, a closing thought, then the keyword line.

### Reels

- Vertical 1080 by 1920, **10 seconds**.
- A Pexels video background and a Pixabay music track. Every Reel gets a new video and a new track, so nothing repeats across the week.
- Text on screen. The words "(READ CAPTION)" fade in partway through, not from the first frame.
- Check every clip for people and animals before using it, since this is a faceless page.
- Vary the look from week to week: list Reels, one-line nature Reels, quote Reels. Never one template.

## The weekly build, step by step

This is the heart of the system. Put one session in your week for it. I build a full week for every page in one go.

1. **Open the chat and say what week you want**: For example: "Build week 7, Dec 4 to 10, for all pages. Read my rules file first." Claude confirms the dates, the daily counts for each page, and the folder name for the batch.
2. **Give new examples when you have them**: See a post or Reel that works? Paste it or screenshot it. Claude adds it as an extra angle. The earlier styles stay in rotation, so the week keeps getting more varied.
3. **Claude writes the text**: Every text post, every caption, every first comment, saved as files in a dated folder so you see exactly what is new.
4. **Claude picks the Pexels photos and videos**: It opens Pexels in your Chrome, finds the clips, checks them for people and animals, and downloads them with numbered names. If a clip fails or has a person in it, it picks another.
5. **Claude picks the music**: Same method on Pixabay: calm piano or cello, no copyright, a different track for every Reel.
6. **Claude builds the pictures**: Python draws each layout at 1080 by 1350 with your fonts and colours.
7. **Claude renders the Reels**: ffmpeg combines video, music and text into 10-second files. Everything is built on your own computer.
8. **Review in the folder**: Claude puts everything into one dated folder, such as `WEEK 7 - Dec 4 to Dec 10`, with a review page that shows every item. Open it in File Explorer and look. Change anything you do not like.
9. **Say go**: Nothing is scheduled until you say it. This one rule keeps you in control.
10. **Upload the batch to Google Drive**: Upload only that week's folder. Every file name starts with the batch date, so you never upload the same thing twice. Set the folder to "anyone with the link can view".
11. **Claude writes the pool**: It matches each Drive file to its post, then writes one pool entry per post with the date, time, text, first comment and media link (chapter 6).
12. **Check the board (optional)**: If you use the Content Board (chapter 9), the week's days turn purple. That means created and waiting.
13. **Clean up your computer**: Delete the raw clips, tracks and photos from Downloads. The finished posts are safe in Drive.

> For the page above that is 28 text posts, 28 pictures and 28 Reels, so 84 pieces for one page. It sounds like a lot, but the same steps repeat, and Claude does the building. Your part is the examples, the review and the go.

## The pool

### Why a pool?

Blotato has a limit on how many posts can wait in its queue at once, and its calendar gets hard to read when several pages are mixed together. The pool solves both. You can build weeks ahead, the pool holds everything, and only tomorrow's posts ever enter Blotato.

### What one pool entry looks like

| Field | What goes in it |
|---|---|
| `page` | Which page and platform, for example `ads_fb` for the Facebook page and `ads_ig` for Instagram. |
| `date`, `time` | When it should publish, in your own time zone. |
| `kind` | `text`, `pic` or `reel`. |
| `text` | The full caption, exactly as it will appear. |
| `firstComment` | The one comment posted right under the post. |
| `mediaUrl` | The public Drive link for the picture or Reel. Empty for text posts. |
| `status` | `pending` until it is sent to Blotato, then `scheduled`. |
| `batch` | A label such as "Week 7 Dec 4-10". |

The entry's name is built the same way every time: `page_date_time_kind`. That makes duplicates impossible and every entry easy to find.

### The morning release

A scheduled task runs every morning at the same time. It finds every pending entry dated today or tomorrow, creates it in Blotato, and marks it `scheduled`. If Blotato is full, the entry stays pending and the task tries again the next morning. Nobody has to remember anything.

## First comments, keywords and DMs

1. **Every post gets one first comment**: It repeats the call to action in plain words, for example "Comment GUIDE and I'll send you the free guide." No links in the comment.
2. **Keep the keyword list tiny**: Four or five words total, one word per link. Plain words that fit the post. Fewer keywords means fewer automations to maintain and fewer chances to send the wrong link.
3. **Let Blotato send the DM**: Create one comment-to-DM automation per keyword. When someone comments the word, Blotato replies publicly and sends the link by message.
4. **Never send DMs by hand in bulk**: Facebook can restrict an account that messages too many people manually. Automations are the safe way.
5. **Switch an automation on only when its product exists**: If a keyword's product is not published yet, leave that automation off and do not use the word in any post.

## Backups and a lighter computer

Your pool lives inside the board's database. That is fine day to day, but a copy outside it protects you if the board is ever deleted by accident.

1. **Export the pool**: Ask Claude to read every pool entry and save them as one JSON file and one spreadsheet-friendly CSV, plus a copy of the board's own saved state.
2. **Zip it with the date**: Name it `BACKUP_Oct27_2026.zip` style, with the real date, so you can tell versions apart.
3. **Put it in Drive**: Upload it to one fixed folder, for example `Blotato`.
4. **Check your media**: Ask Claude to open every media link in the pool without signing in. Anything that fails to open gets fixed before it is due.
5. **Write the date on the board**: The board shows "Backed up" with the date and the file name, so you never wonder.
6. **Delete the raw files**: Once the finished posts are in Drive, the raw clips, tracks and photos only take room. Delete them. Keep your rules file and your free guide files.

Do a backup once a week, right after the weekly build.

## The Content Board

You do not need this on day one. Add it once you have a few weeks of content in the pool and want to see it all at a glance.

![Sample Content Board with four niches](board_sample.png)


The board is a page that shows every page as a row and every day as a column. Each cell tells you how many posts that day has and how many are missing against your daily target.

Above the grid is a to-do list. When a page has only a few days left, the board says "Create content for this page" and tells you the date it runs out. A **Refresh** button reads Blotato and the pool again whenever you want an up-to-date picture. The page names and dates stay pinned while you scroll, so you always know which row you are in.

The board also shows the date of your last backup (chapter 8).

Ask Claude to build yours with the board prompt in the last chapter.

## Running more than one page

The system does not change when you add a page. You add a row to the board, a section to the rules file, and a page code to the pool. I run these from the same weekly session:

| Page | Daily rhythm | What makes it different |
|---|---|---|
| **Digital niche** (Facebook + Instagram) | 4 text, 4 pictures, 4 Reels. Pictures and Reels also on Instagram. | Black and gold. Teaches people to build online without showing their face. |
| **Bible niche** | 5 posts, a mix of Reels and pictures | Faith content, a free peace guide, DM automation on two words. |
| **Quotes niche** (Facebook + Instagram) | 7 a day, the same on both | Quote pictures and Reels. The Instagram twin is written as a second pool entry. |
| **Cooking niche** | 1 text, 1 picture, 1 Reel | A new page. Each product gets its own keyword, and only the free one is live at first. |
| **Pinterest** | 1 pin per board a day | One account with a board per page. Only my own links. |

Different niches, same machine. If you start with one page, add the second only once the first is running without effort.

## Checklist and common problems

### Before you say go

- Every post has a first comment.
- No prices, no income claims, no ages in any text.
- Every keyword is on the approved list and its automation is on.
- Every Reel is 10 seconds and uses a new clip and a new track.
- No clip shows a person or an animal.
- File names start with the batch date.

### Before the week starts

- The week's folder is in Drive and shared by link.
- The board shows purple for every day.
- A backup is saved and the date is on the board.

### When something goes wrong

| Problem | Fix |
|---|---|
| A clip will not download | Ask Claude for a different clip. Some Pexels videos have no vertical version or are very large. |
| A post did not reach Blotato | Check the board for its date. If the date was in the past it will not release. Blotato may have been full, in which case it tries again the next morning. |
| A picture does not show on Facebook | Open the Drive link in a private window. If it asks you to sign in, change the sharing to "anyone with the link". |
| The board says a page is thin | That is the reminder working. Build the next week for that page. |
| Two pool entries have the same name | The later one replaced the first. Check the batch label and the time slot. |
| Claude is drifting from your style | Tell it to re-read the rules file, then add the missing rule to the file. |

## Copy-and-paste prompts

Replace the words in square brackets. Paste each prompt into a new Claude chat.

**1 · Write my rules file**

```
I run a faceless Facebook page called [PAGE NAME]. My promise is: [WHO] [WHAT] without [OBSTACLE].

Interview me, one question at a time, to build a content rules file. Cover: my brand and the faceless rule, my voice and words I never use, my real offers and links, my colours and fonts, my post formats, my comment keywords, and the rule that you must show me everything in a folder and wait for my "go" before scheduling.

Include two rules at the top: (1) always model content on examples I give you, never invent a format; (2) only mention offers listed in this file. Also add: no prices, no income claims, no ages, and no photos of me.

When we are done, save it as a markdown file in my folder called CONTENT RULES.md.
```

**2 · Build a week of content**

```
Read CONTENT RULES.md first. Build [WEEK NAME], [START DATE] to [END DATE], for [PAGES].

Daily target per page: [e.g. 4 text, 4 pictures, 4 Reels].

Use these new examples as extra angles: [PASTE OR ATTACH EXAMPLES].

Rules for this build: every Reel gets a new Pexels video and a new Pixabay music track; every picture gets a new Pexels photo when its layout uses one; check every clip for people and animals; rotate the five picture layouts; vary the hook styles; every post gets a first comment using only these keywords: [KEYWORDS].

Save everything in a folder called [WEEK NAME - dates]. Start every picture and Reel file name with the batch date. Add one review page that shows all of it. Do not schedule anything. Tell me when it is ready and wait for my go.
```

**3 · Add the week to the pool**

```
Go. I uploaded the [WEEK NAME] folder to Google Drive here: [DRIVE FOLDER LINK].

Match each picture and Reel to its post by file name and size. Then write one pool entry per post to the Content Board with: page, date, time, kind, text, firstComment, mediaUrl (public Drive link), status pending and the batch label. Use the entry name page_date_time_kind. Do not write any entry dated in the past. When you are done, tell me how many entries you added and for which dates.
```

**4 · Build my Content Board**

```
Build me a Content Board as a web page that I can keep and refresh.

It needs:
- A grid with one row per page ([LIST MY PAGES AND DAILY TARGETS]) and one column per day for the next 8 weeks, with a total row.
- Each cell shows the number of posts that day and how many are missing against the target. Colour it: green when full, yellow when some are missing, red when nothing is there, purple when posts are waiting in the pool.
- A week label row above the dates.
- Page names and dates pinned while I scroll, in both directions.
- A to-do list above the grid that says "Create content for [page]" with the date it runs out, when a page has about three days or fewer left.
- Click a day to see its posts.
- A Refresh button that reads my scheduled posts from Blotato and the pool, then rebuilds the board.
- A small line under the title showing the date of my last backup.
- Black and gold colours: [YOUR COLOURS].

Store the pool in the page's database, one document per post, using these fields: page, date, time, kind, text, firstComment, mediaUrl, status, batch. Also set up a scheduled task that runs every morning at [TIME] my time, moves pool posts dated today or tomorrow into Blotato, marks them scheduled, then refreshes the board.
```

**5 · Weekly backup and clean-up**

```
Back up my Content Board.

Read every entry in the pool and save them as one JSON file and one CSV, plus a copy of the board's saved state. Zip them as BACKUP_[DATE].zip and put the zip in my Google Drive folder called [FOLDER]. Then open every media link in the pool without signing in and tell me if any fail. Finally, update the backup line on the board with today's date.

After that, list the raw clips, tracks and photos in my Downloads folder and show me what you plan to delete. Wait for my go before deleting anything.
```

---
The Faceless Content System by Josée Bédard, AI Digital Society. This guide describes a working method. It is not a guarantee of results, and it contains no income claims. Check each tool's current terms and plans before you start.