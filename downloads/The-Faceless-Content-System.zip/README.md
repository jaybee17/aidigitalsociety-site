# Faceless Content System: skill pack

Contents:
- `The Faceless Content System.md` : the full guide and prompts in one file (drop it into a Claude chat or project)
- `faceless-content-system/SKILL.md` : the skill itself
- `faceless-content-system/references/` : rules interview, pool schema, weekly checklist, board spec

## Install
1. In Claude, open Settings, then Capabilities (or Skills), and add a skill.
2. Upload the `faceless-content-system` folder as a zip (zip the folder, not its contents).
3. Start a new chat and say: "Use the faceless-content-system skill. Interview me and build my rules file."

## Before you share this pack
Replace nothing here with your own private data. The pack contains placeholders only. Do not add account IDs, links, tokens or prices.
