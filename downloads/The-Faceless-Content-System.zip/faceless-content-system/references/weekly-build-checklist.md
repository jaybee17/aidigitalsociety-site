# Weekly build checklist

## Before building
- [ ] Rules file read
- [ ] Week name, dates, pages and daily targets confirmed
- [ ] New examples from the user added as extra angles (earlier styles stay in rotation)
- [ ] Batch folder named with dates, for example `WEEK 7 - Dec 4 to Dec 10`

## Text
- [ ] One file per text post, each ending with `FIRST COMMENT:`
- [ ] Hooks varied across the week

## Pictures
- [ ] 1080 x 1350
- [ ] One layout per day, rotating
- [ ] New stock photo for each photo-layout picture
- [ ] Caption written, 180 to 320 words, with a numbered list
- [ ] Comment button and page footer present
- [ ] File name starts with the batch date

## Reels
- [ ] 1080 x 1920, 10 seconds
- [ ] New stock video and new music track for every Reel
- [ ] No people or animals in any clip
- [ ] On-screen text readable; "(READ CAPTION)" fades in partway if used
- [ ] File name starts with the batch date

## Review
- [ ] Everything saved in the batch folder with one review page
- [ ] No prices, no income claims, no ages in any text
- [ ] Keywords are only from the approved list
- [ ] User says "go"

## After go
- [ ] User uploads the batch folder to Drive, link sharing on
- [ ] Files matched to posts by name and size
- [ ] Pool entries written
- [ ] Board shows the days as waiting in the pool
- [ ] Backup made and the date written on the board
- [ ] Raw downloads deleted after the user approves the list
