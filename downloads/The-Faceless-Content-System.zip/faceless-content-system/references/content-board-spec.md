# Content Board specification

A single web page (published as an artifact) that shows what is scheduled and what is waiting, for every page.

## Layout
1. Header: title, Refresh button, "updated" time, queue meter (scheduler's cap), backup line.
2. To-do list: one card per page that is running low, saying "Create content for [page]", the date it runs out, and what the next 7 days need. Urgent (3 days or fewer) in red.
3. Grid: rows are pages, columns are days (next 8 weeks). A week-label row sits above the dates. A total row sits at the bottom.
4. Cell: number of posts that day plus "ok", "ready" or "-N" missing.
5. Detail panel: click a cell to list that day's posts with time, kind and first line.
6. Optional sections: weekly growth numbers, a daily pin list, a video channel strip.

## Colours
- Green: full day.
- Yellow: some missing.
- Red: nothing there.
- Purple: the day has posts waiting in the pool (created, not yet sent to the scheduler).

## Behaviour
- Page names and dates stay pinned while scrolling in both directions. The grid scrolls inside its own box, not the whole page.
- Refresh reads scheduled and published posts from the scheduler and pending entries from the pool, rebuilds the board state and saves it.
- A morning task refreshes it too and releases pool entries dated today or tomorrow.
- Daily targets are stored per page and can change from a date onward.

## Data
- `pool`: one document per post (see pool-schema.md).
- `board/state`: the rebuilt board.
- `board/backup`: `{ date, where, count }`, shown under the title.

## Setup order
1. Connect the scheduler to the artifact.
2. Publish the page with an empty pool.
3. Write a few test pool entries and refresh.
4. Create the morning task.
5. Only then build the first full week.
