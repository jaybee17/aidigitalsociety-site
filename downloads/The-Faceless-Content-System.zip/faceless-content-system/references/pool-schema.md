# The content pool

Every finished post is stored as one entry in the pool. A scheduled task releases entries to the scheduler one day ahead. The assistant never schedules posts directly.

## Entry name

`<page>_<date>_<HHMM>_<kind>`, for example `ads_fb_2026-12-04_0700_text`.

## Fields

| field | value |
|---|---|
| page | a short code for the page and platform, such as `page1_fb`, `page1_ig` |
| date | `YYYY-MM-DD` in the user's time zone |
| time | `HH:MM`, 24 hour |
| kind | `text`, `pic` or `reel` |
| text | the full caption, exactly as it should publish |
| firstComment | the first comment, or an empty string |
| mediaUrl | public link to the picture or Reel (Drive: `https://drive.google.com/uc?export=download&id=<fileId>`), or empty for text posts |
| mediaType | `reel` for Reels only |
| status | `pending` |
| batch | a label such as `Week 7 Dec 4-10` |
| createdBy | the chat or skill that wrote it |

## Rules

1. Show the user the review page and wait for "go" before writing.
2. Media must already be in the shared Drive folder before its entry is written.
3. Write entries in batches of up to 50.
4. Never write an entry dated in the past. Never change an entry whose status is `scheduled`.
5. If the same post goes to two platforms, write two entries with different page codes and the same text and media.
6. Report: "N posts added to the pool for [dates]. They go to the scheduler one day ahead."

## Morning release (scheduled task)

1. Read every `pending` entry dated today or tomorrow.
2. Create each in the scheduler. On success set status `scheduled` and store the scheduler's post id.
3. If the scheduler's queue is full, leave the entry `pending` and try the next morning.
4. Refresh the board.
