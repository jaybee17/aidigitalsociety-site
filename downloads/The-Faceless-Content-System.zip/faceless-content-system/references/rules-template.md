# Rules file interview

Interview the user one question at a time, then save the answers as `CONTENT RULES.md`.

Questions, in order:

1. Page name and platforms (Facebook page, Instagram account).
2. The promise: "Helping [who] do [what] without [obstacle]."
3. Who the page speaks to. Confirm no age or gender targeting unless the user insists.
4. Faceless rule: confirm no photos of the user, and what the logo is.
5. Voice: three adjectives, and a list of words and habits to avoid (hype, guru talk, exclamation marks, income claims).
6. Colours (hex codes) and fonts.
7. Offers: each real product or free guide, its link, and one line on what it is. Warn the user that only listed offers may be mentioned.
8. Comment keywords: at most five, plain words, and which link each sends. Confirm a DM automation exists for each before the word is used in a post.
9. Daily rhythm per page: how many text, picture and Reel posts, and posting times.
10. Picture layouts: up to five, each described and tied to an example post.
11. Reel styles: examples to model, stock sources, music style.
12. Review rule: all work goes in a folder first, and nothing is scheduled until the user says "go".

## File structure to write

```
# [PAGE] Content Rules
## The brand
## Rule 1: model, never invent
## Rule 2: real offers only
## Voice
## Colours and fonts
## Text posts
## Picture posts (layouts)
## Captions
## Reels
## Comment keywords and first comments
## Review and scheduling
```
