---
name: faceless-content-system
description: Plan, build, review, pool and schedule a week of faceless Facebook and Instagram content (text posts, picture posts, Reels) for one or more pages, using a brain file, a content pool and a Content Board. Use when asked to build a week of content, add a batch to the pool, back up the pool, or set up the board.
---

# Faceless Content System

This skill runs a weekly production cycle for faceless social pages. Content is built in bulk, reviewed in a folder, stored in a pool, and released to the scheduler one day ahead.

## Before anything else

1. Read `CONTENT RULES.md` in the user's folder. If it does not exist, run the interview in `references/rules-template.md` and save it first.
2. Read `references/pool-schema.md` so pool entries are written exactly.
3. Confirm the week name, the start and end dates, the pages, and the daily target for each page.

## Two rules that never change

1. **Model, never invent.** Build every format from an example the user supplied. Copy the framework, hook pattern, list structure, caption shape and call to action, then swap in the user's topic. If no example exists for a format, ask for one.
2. **Real offers only.** Mention only the offers listed in the brain file. Never invent a product, a link or a price.

## Weekly cycle

Follow `references/weekly-build-checklist.md`. In short:

1. Confirm dates, pages and daily targets. Name the batch folder with the dates.
2. Write all text, captions and first comments.
3. Find and download one new stock video and one new music track per Reel, and one new stock photo per photo-layout picture. Check every clip for people and animals. Never reuse across pieces.
4. Build the pictures (Python with Pillow) and the Reels (ffmpeg), locally.
5. Save everything in the dated folder, with every picture and Reel file name starting with the batch date. Add one review page showing all items.
6. Stop. Tell the user it is ready. Do not schedule. Wait for an explicit "go".
7. After "go", and after the user has uploaded the batch to Drive, match files to posts and write pool entries. Do not call the scheduler directly.
8. Report how many entries were added and for which dates.

## Hard limits for all content

- No income claims or earnings figures, ever.
- No prices in posts, captions, Reels or comments.
- No ages or gender targeting.
- No photos of the user.
- Every post has exactly one first comment, with no links, using only keywords listed in the brain file.
- Reels are 10 seconds. If the text "(READ CAPTION)" is used, it fades in partway through.
- Vary hook styles, angles and Reel looks every week. Rotate the picture layouts one per day.

## Other tasks

- **Add to the pool:** see `references/pool-schema.md`.
- **Set up the board:** see `references/content-board-spec.md`.
- **Backup:** export every pool entry to JSON and CSV, add a copy of the board state, zip with the date, save to the user's Drive backup folder, open every media link without signing in and report failures, then update the backup line on the board.
- **Clean up:** list raw downloaded clips, tracks and photos, show the list and total size, and delete only after the user says go.
